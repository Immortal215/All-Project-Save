import SwiftUI

struct NounView: View {
    @EnvironmentObject var model:Model
    var body: some View {
        VStack {
            TextField("What noun would you like?", text: $model.noun)
                .textFieldStyle(.roundedBorder)
            
            NavigationView(){
                NavigationLink { 
                    VerbView()
                } label: { 
                    Text("Submit Noun")
                        .font(Font.custom("", fixedSize: 100))
                        .fontDesign(.serif)
                        .foregroundColor(.blue)
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
