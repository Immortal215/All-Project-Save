import SwiftUI

struct StoryView: View {
    @EnvironmentObject var model:Model
    @State var alert = false
    @State var emoji = ""
    @State var sentence3 = ""
    @State var toggle2 = 0
    var body: some View {
        
        VStack {
            VStack {
                Button() {
                    toggle2 += 1
                } label : {
                    if toggle2 == 0 {
                        Text("Create Story")
                            .shadow(color: .blue,radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    } else {
                        Text("Create New Story")
                            .shadow(color: .blue,radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/) 
                    }

                }
                if toggle2 > 0 {
                    let sentence = model.wordPlay().split(separator: " ")
                    Text(sentence[0] + " ")
                        .foregroundColor(.red)
                    + Text(sentence[1] + " ")
                        .foregroundColor(.blue)
                    + Text(sentence[2] + " ")
                    + Text(sentence[3] + " ")
                    + Text(sentence[4] + " ")
                    + Text(sentence[5] + " ")
                    + Text(sentence[6] + " ")
                        .foregroundColor(.yellow)
                    + Text(sentence[7] + " ") 
                    + Text(sentence[8] + " ")
                }
                
            }
            TextField("Look For Word", text: $model.find)
                .textFieldStyle(.roundedBorder)
            Button (){
                var sentence2 = model.story
                if sentence2.contains(model.find) {
                    print("works")
                    emoji = "😄"
                    alert.toggle()
                } else {
                    emoji = "🥲"
                    alert.toggle()
                }
            } label: {
                Text("Look For Word")  
                
            }
            .shadow(color: .blue,radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            .alert("\(emoji)", isPresented: $alert) { 
                Button("OK") {
                    
                }
            }
            VStack {
                Divider()
                TextField("Replace With Word", text: $model.change)
                    .textFieldStyle(.roundedBorder)
                VStack {
                    Button {
                        sentence3 = model.story
                        sentence3 = sentence3.replacing(model.find, with: model.change)

                        
                    } label: {
                        Text("Replace With Word")  
                            .shadow(color: .blue,radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                    }
                    
                }
                Text("New Sentence : \(sentence3)")
            }
            
            
            .navigationViewStyle(.stack)
            
        }
    }
    
}


