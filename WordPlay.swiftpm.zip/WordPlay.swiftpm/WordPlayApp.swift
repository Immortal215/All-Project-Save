import SwiftUI

@main
struct WordPlayApp: App {
    @StateObject var model = Model()
    var body: some Scene {
        WindowGroup {
            Text("wOrD pLaY") 
                .bold()
                .font(Font.custom("", fixedSize: 100))
                .fontWidth(.expanded)
                .fontDesign(.rounded)
                .foregroundColor(.brown)
            Divider()
            StartView()
                .environmentObject(model)
                   }
    }
}
