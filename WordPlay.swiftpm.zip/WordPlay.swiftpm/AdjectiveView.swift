import SwiftUI

struct AdjectiveView: View {
    @EnvironmentObject var model:Model
    var body: some View {
        VStack {
            TextField("What adjective would you like?", text: $model.adjective)
                .textFieldStyle(.roundedBorder)
            
            NavigationView(){
                NavigationLink { 
                    StoryView()
                } label: { 
                    Text("Submit Adjective")
                        .font(Font.custom("", fixedSize: 100))
                        .fontDesign(.serif)
                        .foregroundColor(.blue)
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
