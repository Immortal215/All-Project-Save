import SwiftUI

class Model:ObservableObject {
    //make a function to reset the game
    var noun = ""
    var verb = ""
    var adjective = ""
    var story = ""
    var find = ""
    var change = ""

    func wordPlay() -> String{
        let storyInt = Int.random(in: 1..<4)
        if storyInt == 1 {
            story =  ("\(noun) \(verb.lowercased()) the big banana and \(adjective.lowercased()) consumed C-Money!")
        } else if storyInt == 2 {
            story =  ("\(noun) \(verb.lowercased()) with C-Money and his \(adjective.lowercased()) cool sunglasses!")
        } else if storyInt == 3 {
            story =  ("\(noun) \(verb.lowercased()) the rizzler C-Money and \(adjective.lowercased()) stole him!")
        } else if storyInt == 4 {
            story =  ("\(noun) \(verb.lowercased()) C-Money along with his \(adjective.lowercased()) big dumptruck!")
        }
        return story
        
    }
}
