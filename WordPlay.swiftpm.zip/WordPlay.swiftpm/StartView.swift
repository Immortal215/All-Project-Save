import SwiftUI

struct StartView: View {
    @EnvironmentObject var model:Model
    var body: some View {
        VStack {
            NavigationView(){
                NavigationLink { 
                    NounView()
                } label: { 
                    Text("Start")
                        .font(Font.custom("", fixedSize: 100))
                        .fontDesign(.serif)
                        .foregroundColor(.blue)

                }

            }
        }
        .navigationViewStyle(.stack)
    }
}
