import SwiftUI

struct VerbView: View {
    @EnvironmentObject var model:Model
    var body: some View {
        VStack {
            TextField("What verb would you like?", text: $model.verb)
                .textFieldStyle(.roundedBorder)
            
            NavigationView(){
                NavigationLink { 
                    AdjectiveView()
                } label: { 
                    Text("Submit Verb")
                        .font(Font.custom("", fixedSize: 100))
                        .fontDesign(.serif)
                        .foregroundColor(.blue)
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
