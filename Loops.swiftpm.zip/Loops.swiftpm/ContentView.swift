import SwiftUI

struct ContentView: View {
    @State var myOutput = ""
    @State var favoriteRestraunt = ["Potbelly", "Olive Garden", "Fat Rosie's", "Chipotle"]
    @State var fruit = ["Banana", "Apple", "Pear", "Grape"]
    @State var bands = ["ACDC", "Rage Against the Machine", "Korn"]
    @State var pizzaToppings = ["Pineapple", "Olives", "Green Peppers", "Mushrooms"]
    @State var contact = ["Name" : "Colin", "Nickname" : "C-Money","Address" : "801 kensington", "Phone #" : "555555555", "Zipcode" : "60056"]
    var body: some View {
        Text("My Output : \(myOutput)")
            .font(.largeTitle)
        VStack(spacing:20) {
            Button("Array 1") {
                var output = ""
                for i in fruit {
                    output += "\(i)\n"
                }
                myOutput = output
            }
            Button("Array 2") {
              var output = "" 
                for i in 0...2 {
                    output += "\(favoriteRestraunt[i])\n"
                }
                myOutput = output
            }
            Button("Array 3") {
                var output = "" 
                for i in 0..<2 {
                    output += "\(bands[i])\n"
                }
                myOutput = output
            }
            Button("Array 4") {
                var output = "" 
                for i in 0..<pizzaToppings.count {
                    output += "\n\n\(pizzaToppings[i])"
                }
                myOutput = output 
            }
            Button("Dictionary") {
                var output = ""
                for (key,value) in contact {
                    output += "\(key) : \(value)\n" 
                }
                myOutput = output
            }
        }
        .font(.largeTitle)
    }
}
