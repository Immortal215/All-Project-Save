import SwiftUI

struct RetrieveView: View {
    
    @AppStorage("number2") var number2: String?
    //    @AppStorage("url2") var url2: URL?
    @State var array: [Double] = []
    
    @State var name = ""
    @State var age = ""
    @State var phoneNumber = ""
    
    
    //MARK: MVP - Part III
    @AppStorage("number1") var number1: Int?
    
    //MARK: Stretch #1 - Part III
    @AppStorage("url1") var url1: String?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Group {
                TitleView(name: "MVP")
                HStack {
                    Text("Number1: ")
                    Text("\(number1 ?? 0)")
                }
                HStack {
                    Text("Number2: ")
                    Text("\(number2 ?? "Not Loaded Yet")")
                }
            }
            
            Group {
                TitleView(name: "Stretch #1")
                //TODO: Stretch #1
                Link("Load URL #1", destination: URL(string: url1)!)
                //                Link("Load URL #2", destination: url2)
            }
            
            Group {
                TitleView(name: "Stretch #2")
                ForEach(array, id: \.self) { value in
                    Text("\(value) ")
                }  
            }
            
            Group {
                TitleView(name: "Stretch #3")
                HStack {
                    Text("Name: ")
                    Text(name)
                }
                HStack {
                    Text("Age: ")
                    Text(age)
                }
                HStack {
                    Text("Phone Number: ")
                    Text(phoneNumber)
                }  
            }
        }
        .frame(maxWidth: .infinity)
        .padding()
        .font(.title)
        .onAppear(perform: {
            //MARK: MVP - Part IV
            
            
            
            
            
            //MARK: Stretch #1 - Part IV
            
            
            
            
            
            //MARK: Stretch #2 - Part II
            
            
            
            
            
            //MARK: Stretch #3 - Part II
            
            
            
            
            
        })
    }
}

