import SwiftUI

struct ContentView: View {
    @State var nameTextFieldText = ""
    @State var number = 0
    var body: some View {
        VStack {
            Text("Text Fields")
                .font(.largeTitle)
                .fontWeight(.bold)
            TextField("Enter Name", text: $nameTextFieldText)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .multilineTextAlignment(.center)
                .padding()
            Text(nameTextFieldText)
                .font(.title)
                .fontWeight(.bold)
                .padding()
            Button(action : {
                if let enteredString = Int(nameTextFieldText){
                    print("Entered text is an integar: \(enteredString)")
                } else {
                    print("Entered text is not an integar: \(nameTextFieldText)")
                }
            }, label : {
                Text("Using Button")
                    .font(.title)
            })
            TextField("Enter Number Here", value: $number, format: .number)
                .textFieldStyle(.roundedBorder)
                .padding()
            Text("The number entered is : \(number)")
            
        }
    }
}
