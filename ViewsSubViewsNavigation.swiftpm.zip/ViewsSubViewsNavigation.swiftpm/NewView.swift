import SwiftUI

struct NewView: View {
    var body: some View {
        Text("a")
    }
}
