import SwiftUI

struct MyView: View {
    var body: some View {
        VStack{
            Text("MyView")
           
            BoxView(number:1)
            BoxView(number:2)
            BoxView(number:3)
            
            NavigationView{
                NavigationLink(
                    destination: NewView(),
                    label: {
                        Text("Press Me")
                    })
            }
        }
    }
}

struct BoxView: View {
    var number: Int
    var body: some View{
        Text("\(number)")
            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .background(.green)
            .foregroundColor(.white)
    }
}
