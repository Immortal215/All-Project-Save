import SwiftUI
import AVFoundation

struct ContentView: View {
    @State var isShowing = true 
    @State var scale = 1.0
    @State var animationAmount:CGFloat = 1 
    @State var x:CGFloat = 0
    @State var y:CGFloat = 0
    @State var z: CGFloat = 0  
    @State var angle: Double = 0
    
    var body: some View {
        VStack {
            Button {
                isShowing.toggle()
                scale += 0.5
                withAnimation(.interactiveSpring){
                    animationAmount += 10
                }
            } label: {
                Text("C-Money")
                    .opacity(isShowing ? 1 : 0)
                    .animation(.easeIn(duration: 1.0),value: isShowing)
                    .scaleEffect(scale, anchor: .center)
            }
            .frame(width:200, height: 200)
            .background(isShowing ? .white : .black)
            .animation(.default, value: isShowing)
            .transition(.scale)
            .animation(.easeIn(duration: 1.0))
            .padding(20)
            .clipShape(Circle())
            .rotation3DEffect(.degrees(animationAmount), axis: (x: 0, y:1, z:0)) 
                              
            Text("We miss you")
                .opacity(isShowing ? 0 : 1)
                .animation(.easeInOut(duration: 2.0),value: isShowing)
            Text("something")
                .frame(width:100, height:50, alignment: .center)
                .background(.black)
                .foregroundColor(.white)
                .rotation3DEffect(Angle(degrees: angle), axis: (x: x, y: y, z: z))
            Spacer()
            Stepper("Angle: \(angle)", value:$angle)
            Stepper("X: \(x)", value:$x)
            Stepper("Y: \(y)", value:$y)
            Stepper("Z: \(z)", value:$z)
            Spacer()
            


        }
    }
}
