import SwiftUI

import MapKit

struct ContentView: View {
    let tower = CLLocationCoordinate2D(latitude: 37.334663403080455, longitude: -122.00888036046938)   

    @State var camera: MapCameraPosition = .automatic
    
    var body: some View {
        VStack {
            
            Map(position: $camera) {
                
                Annotation("Apple", coordinate: tower) { 
                    Image(systemName: "target")
                }
                // or system image
                Marker("Apple Park", monogram: Text("Apple"), coordinate: tower)
                    .tint(.blue)
            
                
            }
            .safeAreaInset(edge:.bottom) {
                HStack {
                    Spacer()

                    Button {
                        camera = .region(MKCoordinateRegion(
                            center: tower, 
                            latitudinalMeters: 200,
                            longitudinalMeters: 200)) 
                    } label : {
                        Text("Apple Park")
                            .foregroundStyle(.white)
                            .shadow(radius: 10)
                    }
                    Spacer()
                }
                .padding(.top)
                .background(.thinMaterial)
            }
            .mapStyle(.imagery)
        }
    }
}
