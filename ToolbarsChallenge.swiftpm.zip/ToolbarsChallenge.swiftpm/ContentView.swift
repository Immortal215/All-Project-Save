import SwiftUI

struct ContentView: View {
    var timer: Timer {
        //MARK: Stretch #3 - Part I
        Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) {_ in
            progressTime += 1
        }
    }
 
    var minutes: String {
        //MARK: Stretch #3 - Part II
        let time = ((progressTime/6000) % 60) 
        return time < 10 ? "0\(time)" : "\(time)"
    }
    
    var seconds: String {
        //MARK: Stretch #3 - Part III
        let time = (progressTime/100) % 60 
        return time < 10 ? "0\(time)" : "\(time)"
    }
    
    //MARK: Stretch #3 - Part IV
    var hundreths: String {
        //MARK: Stretch #3 - Part III
        let time = progressTime % 100
        return time < 10 ? "0\(time)" : "\(time)"
    }
    
    
    
    @State private var progressTime = 0
    @State var myTimer:Timer?

    var body: some View {
        HeaderView()
        NavigationStack {
            //MARK: Stretch #3 - Part V
            Text("\(minutes):\(seconds):\(hundreths)")
                .font(.system(size: 100))
                .toolbar { 
                    //MARK: MVP
                    ToolbarItem(placement: .topBarLeading) { 
                        
                        Button {
                            myTimer = timer
                        } label : {
                            Text("Start")
                        }
                    }
                    
                    ToolbarItem(placement: .topBarTrailing) { 
                        Button {
                            myTimer?.invalidate()
                        } label : {
                            Text("Stop")
                        }
                    }
                    
                    ToolbarItem(placement: .bottomBar) { 
                        Button {
                            progressTime = 0
                        } label : {
                            Text("Reset")
                        }
                    }
                
                    
                    
                    
                    
                    //MARK: Stretch #1
                    
                    
                    
                    
                    
                    //MARK: Stretch #2
                    
                    
                    
                    
                    
                }
        }
        FooterView()
    }
}
