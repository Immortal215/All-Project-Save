import SwiftUI

struct Stretch1View: View {
    var body: some View {
        //MARK: Stretch #1 - Part II
        VStack {
            HStack {
                recieveText(textToDisplay: "X", color: .white)  
                recieveText(textToDisplay: "O", color: .white)  
                recieveText(textToDisplay: "X", color: .blue)  
            }
            HStack {
                recieveText(textToDisplay: "O", color: .white)  
                recieveText(textToDisplay: "X", color: .blue)  
                recieveText(textToDisplay: "O", color: .white)  

            } 
            HStack{
                recieveText(textToDisplay: "X", color: .blue)  
                recieveText(textToDisplay: "O", color: .white)  
                recieveText(textToDisplay: "O", color: .white)  

            }
        }
        
    }
}

//MARK: Stretch #1 - Part I
struct recieveText: View {
    var textToDisplay: String
    var color: Color
    var body: some View {
       Text("\(textToDisplay)")
            .font(.custom("a", fixedSize: 50))
            .frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/, width: 5)
            .background(color)
    }
}


