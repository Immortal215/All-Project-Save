import SwiftUI

struct Stretch2View: View {
    var body: some View {
        //MARK: Stretch #2
        VStack {
            NavigationView{
                NavigationLink(
                    destination: Image("Image2"),
                    label: {
                        Image(systemName: "square.and.arrow.up")
                    })
            } 
            NavigationView{
                NavigationLink(
                    destination: Image("images-1"),
                    label: {
                        Image(systemName: "square.and.arrow.up.fill")
                    })
            } 
        }
    }
}
