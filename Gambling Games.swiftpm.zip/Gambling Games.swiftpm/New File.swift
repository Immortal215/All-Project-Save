import SwiftUI

struct EnterView:View {
    let games = ["Balance", "Slots", "Roulette", "Something"]
    var body: some View {
        List(games, id: \.self) { i in 
            NavigationLink(i) {
                if i == "Balance" {
                } else if i == "Slots" {
                } else if i == "Roulette" {
                } else {
                }
            }
        }
    }
}
