import SwiftUI

struct ContentView: View {
@State var money = 0 
@State var monkeyMoney = 0 
    var body: some View {
        VStack {
            Button(){
                if money <= 10 || money >= -10 {
                    money += 6  
                } else {
                    monkeyMoney += 2
                }
            } label: {
                Image(systemName: "suit.diamond")
                    .resizable()
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            }
            .offset(x: Double(money), y: Double(money))
            .offset(x: Double(money*(monkeyMoney + 1)), y: Double(money/(monkeyMoney + 1)))
            Button {
                
            } label : {
                Text("Enter")
                    .font(Font.custom("Zapfino", fixedSize: 40))
                    .foregroundColor(.red)
            }
            Button(){
                if money <= 10 || money >= -10 {
                    money -= -3
                } else {
                    monkeyMoney += 7
                }
            } label: {
                Image(systemName: "suit.diamond")
                    .resizable()
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            }
            .offset(x: Double(-money), y: Double(money))
            .offset(x: Double(money*(monkeyMoney - 1)), y: Double(money/(monkeyMoney - 1)))
            
           
        }
    }
}
