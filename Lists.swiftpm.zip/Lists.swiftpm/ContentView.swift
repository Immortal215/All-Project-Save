import SwiftUI

struct ContentView: View {
    @State var items:[String] = ["Milk", "Marshmallow", "Chocolate"]
    @State var text = ""
    @State var itemsQuantity: [ShoppingItem] = [
        ShoppingItem(name: "Apples", quantity: 5), 
        ShoppingItem(name: "Pineapple"),
        ShoppingItem(name: "Monkies", quantity: 2)
    ]
    
    var body: some View {
        VStack { 
            
            List {
                Text("Protein Powder")
                Text("Pizza")
                Text("Eggs")
                Text("Cheese")
                Text("Fruit")
                
            }
            Divider()
            HStack {
                TextField("Add to below", text: $text)
                Button {
                    if text == "" {
                        
                    } else {
                    items.append(text)
                    text = ""
                    }
                } label : {
                    Image(systemName: "plus.app")
                        .resizable()
                        .frame(width:30, height:30)
                }
            }    
            
            List(items, id: \.self) { currentItem in
                Text(currentItem)
            }
            Divider()
            List(itemsQuantity, id: \.self) { i in
                Text(i.name)  
                    .font(.largeTitle)
                
                // optional, if the user does not have a quantity, set it to 1
                Text("Quantity : \(i.quantity ?? 1)")
            }

        }

    }
}
