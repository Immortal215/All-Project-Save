import SwiftUI

struct ShoppingItem:Hashable {
    var name:String
    var quantity:Int? 
}
