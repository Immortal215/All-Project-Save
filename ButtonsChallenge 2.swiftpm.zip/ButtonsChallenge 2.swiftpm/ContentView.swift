//  Buttons Challenge
//
//  Created by Ben Button
//  Copyright © 2023 MobileMakersEdu. All rights reserved.

import SwiftUI

struct ContentView: View {
    @State var changeBackground: Bool = true
    @State var counter: Int = 0
    @State var lightBulbStatus: String = "On"
    @State var showAlert = false
    var body: some View {
        VStack(spacing: 40) {
            
            Group {
                Divider()
                Text("Buttons Challenge")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .font(.title)
                Divider()
            }
            
            //MARK: MVP
            HStack {
                Button("1"){
                    print("Button #1 Was Pressed")
                }
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(.red)
                .foregroundColor(.white)
                Button("2") {
                    print("Button #2 Was Pressed")
                }
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(.red)
                .foregroundColor(.white)
                
            }
            
            
            
            
            
            //MARK: Stretch #1
            Button("Change Background"){
                if (changeBackground == true){
                    changeBackground = false
                } else{
                    changeBackground = true
                }
                
                
            }
            .background(.blue, in:  RoundedRectangle(cornerRadius:10))
            .foregroundColor(.white)
            
            
            
            
            
            //MARK: Stretch #2
            Button("\(counter)"){
                counter += 1
            }
            .background(.gray, in: Capsule())
            .foregroundColor(.white)
            
            
            
            
            
            
            //MARK: Stretch #3
            Button (){
                showAlert.toggle()
            } label : {
                Text(Image(systemName :"key"))
                    .imageScale(.large)
                    .frame(width: 200, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .background(in: Circle())
                    .foregroundColor(.green)
                    .shadow(color:.black, radius: 10, x: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/, y: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/)
                    .alert("Stretch #3 Complete", isPresented: $showAlert) { 
                        //the role: .cancel thing is not neccesary but useful for future
                        Button("OK", role: .cancel) {
                            
                        }
                    }
            }
            
            
            
            
            //MARK: Stretch #4
            Button () {
                if lightBulbStatus == "Off" {
                    lightBulbStatus = "On"
                } else {
                    lightBulbStatus = "Off"
                }
            } label : {
                if lightBulbStatus == "On" { 
                    Image(systemName :"lightbulb.fill")
                        .foregroundColor(.yellow)
                } else {
                    Image(systemName: "lightbulb")
                        .foregroundColor(.yellow)
                }
            }
            
            Text("The light bulb is \(lightBulbStatus)") 
                .foregroundColor(.yellow)
            
            
            
            
            Group {
                
                Image("MobileMakersEduNB")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .scaledToFit()
                
            }
            
            
        }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
        .background(changeBackground ? .white : .black)
    }
}



