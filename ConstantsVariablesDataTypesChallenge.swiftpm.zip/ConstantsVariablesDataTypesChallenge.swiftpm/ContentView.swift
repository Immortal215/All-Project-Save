//  ConstantsVariablesDataTypes Challenge
//
//  Created by Dr. Datatype
//  Copyright © 2023 MobileMakersEdu. All rights reserved.


import SwiftUI

struct ContentView: View {
    
    //MARK: MVP
    @State var showMVP = false
    @State var firstName = "Sharul "
    
    
    
    var body: some View {
        
        //MARK: Stretch #1
        @State var lastName = "Shah"
        @State var titleName = "Mr. "
        @State var greeting = "Hello, " + titleName + lastName
        
        
        
        //MARK: Stretch #2
        @State var name1 = "Jamal"
        @State var name2 = "Jeff"
        @State var name3 = "Sharul"
        @State var name4 = "Daniel"
        @State var teamOne = name1 + ", " + name2
        @State var teamTwo = name3 + ", " + name4
        
        
        
        //MARK: Stretch #3
        let name1Score = 13
        let name2Score = 15
        let name3Score = 12
        let name4Score = 17
        let names1Score = "\(name1) - \(name1Score) "
        let names2Score = "\(name2) - \(name2Score) "   
        let names3Score = "\(name3) - \(name3Score) " 
        let names4Score = "\(name4) - \(name4Score) " 
        @State var teamHighScoreOne = names1Score + "& " + names2Score
        @State var teamHighScoreTwo = names3Score + "& " + names4Score
        
        
//        --
        
        
    
        
        
        VStack {
            VStack {
                Group {
                    Divider()
                    Text("Constants, Variables\nData Types Challenge")
                        .frame(maxWidth: .infinity, alignment: .center)
                        .font(.title)
                    Divider()
                }
                //TODO: MVP, Uncomment the line below
                Button("MVP") { showMVP.toggle() }.alert("Your Name is \(firstName)", isPresented: $showMVP){}.font(.largeTitle).foregroundColor(.primary)
                
                Spacer()
                
                Text("Stretch 1")
                    .font(.largeTitle)
                    .underline()
                
                //TODO: Stretch #1, Uncomment the line below
                Text(greeting)
                
                Spacer()
            }
            VStack {
                
                Text("Stretch 2")
                    .font(.largeTitle)
                    .underline()
                
                //TODO: Stretch #2, Uncomment the line below
                Text("Team 1: \(teamOne)\nTeam 2: \(teamTwo)")
                
                
                Spacer()
                Text("Stretch 3")
                    .font(.largeTitle)
                    .underline()
                
                //TODO: Stretch #3, Uncomment the line below
                Text("\(teamHighScoreOne)\n\(teamHighScoreTwo)")
                
                Spacer()
            }
            
            Group {
                Spacer()
                Image("MobileMakersEdu")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .scaledToFit()
            }
        }
        .padding()
    }
}
