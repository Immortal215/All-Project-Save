import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            VStack {
                NavigationLink { 
                
                    Text("Return on C-Money")
                    
                } label: {
                    
                    Text("Colin")
                }
                .toolbar {
                    
                    Button {
                        
                    } label : {
                    
                        Text("Save")
                    }
                    
                    
                    Button {
                        
                    } label : {
                        
                        Text("Delete")
                    }
                    
                    
                    Button { 
                        
                    } label : {
                        
                        Text("Search")
                    }
                    
                    
                } 
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) { 
                        Text("Home")
                    }
                    
                    // principal puts in center
                    ToolbarItem(placement: .principal) {
                        Image(systemName:"pencil")
                    }
                    
                    ToolbarItem(placement: .navigationBarLeading) {
                        Image(systemName: "bus")
                    }
                }
                .navigationTitle("Home")
                .navigationBarTitleDisplayMode(.inline)
            }
            
        }
    }
}
