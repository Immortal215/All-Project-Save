import SwiftUI

class StarTravel {
    var firstStarName: String 
    var secondStarName: String 
    
    init() {
        firstStarName = ""
        secondStarName = ""
    }
}
