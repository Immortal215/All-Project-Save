import SwiftUI

struct SummaryView: View {
    @Binding var myStarVisits: StarTravel
    var body: some View {
        Text("You first visited a \(myStarVisits.firstStarName)")
        Text("You first visited a \(myStarVisits.firstStarName.count) lightyears")
        Divider()
        Text("You second visited a \(myStarVisits.secondStarName) star")
        Text("You second visited a \(myStarVisits.secondStarName.count) lightyears")
    }
}
