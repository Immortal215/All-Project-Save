import SwiftUI

struct ContentView: View {
    @Binding var myStarVisits : StarTravel
    var body: some View {
          NavigationView {
              
              VStack {
                  TextField("First Star to Visit", text: $myStarVisits.firstStarName)
                      .textFieldStyle(.roundedBorder)
                      .padding()
                      .autocorrectionDisabled(true)
                  NavigationLink("Go to First Star") {
                      Star1View(myStarVisits: $myStarVisits)
                }
              }
              .navigationTitle("Intergalactic Traveler")
              .frame(maxWidth:.infinity,maxHeight: .infinity)
              .background(
                Image("Space")
                    .resizable()
                    .scaledToFill()
              )
          }
          .navigationViewStyle(.stack)
    }
}
