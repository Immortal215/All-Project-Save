import SwiftUI

struct Star2View: View {
    @Binding var myStarVisits: StarTravel
    var body: some View {
        VStack {
            Image("\(myStarVisits.secondStarName)")
                .resizable()
                .scaledToFit()
            NavigationLink("Summary of Stars") {
                SummaryView(myStarVisits: $myStarVisits)
            }
            
        }
    }
}


