import SwiftUI

struct Star1View: View {
    @Binding var myStarVisits: StarTravel
    var body: some View {
        VStack {
            Image("\(myStarVisits.firstStarName)")
                .resizable()
                .scaledToFit()
            TextField("Second Star to Visit", text: $myStarVisits.secondStarName)
                .textFieldStyle(.roundedBorder)
                .padding()
                .autocorrectionDisabled(true)
            NavigationLink("Go to Second Star") {
                Star2View(myStarVisits: $myStarVisits)
            }
            
        }
    }
}

