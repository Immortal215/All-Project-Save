import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Images Demo")
            Image("Image1")
                .resizable()
                .aspectRatio(1.3, contentMode: .fit)
                .frame(width: 300, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(.black)
            Image("Image2")
                .resizable()
                .aspectRatio(0.8, contentMode: .fit)
                .frame(width: 300, height: 300, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .background(.black)
            Image(systemName:"trash")
                .resizable()
                .aspectRatio(1.5,contentMode:.fit)
            Image(systemName:"figure.fall")
        //these apple images can be found in the top on the fourth icon
                .resizable()
                .aspectRatio(1.5,contentMode:.fit)
                
        }
    }
}
