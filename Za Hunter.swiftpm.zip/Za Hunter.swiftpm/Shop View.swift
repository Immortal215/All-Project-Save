import SwiftUI
import MapKit
import CoreLocation

struct ShopView: View {
    @State var name = String()
    @State var address = String()
    @State var phoneNumber = String()
    @State var screenWidth = UIScreen.main.bounds.width
    
    var body: some View {
        Text(name)
            .font(.largeTitle)
            .fontWeight(.bold)
        
        Divider()
            .frame(width: screenWidth/2)
        
        Text("Address : \(address)")
            .padding()
        
        Button {
            UIApplication.shared.canOpenURL(URL(string: "\(phoneNumber)")!)
        } label : {
            Text("Phone Number : \(phoneNumber)")
                .foregroundStyle(.blue)
        }
        
    }
}
