import SwiftUI
import MapKit
import CoreLocation

struct ContentView: View {
    
    @State var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 42.07925960001393, longitude: -87.9491742324852), span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
    @State var shopsLocation: [Shop] = []
    @State var clicked = false

    var body: some View {
        NavigationStack {
            ZStack {
                Map(coordinateRegion: $region, showsUserLocation: true, userTrackingMode: .constant(.follow), annotationItems: shopsLocation) { shop in
                    MapAnnotation(coordinate: shop.coordinate) { 
                        if clicked == true {
                        
                            NavigationLink {
                                ShopView(name: shop.name, address: shop.placemark, phoneNumber: shop.phoneNumber)
                            } label: {
                                VStack {
                                    Image(systemName: "mappin")
                                        .resizable()
                                        .foregroundStyle(.red)
                                        .frame(width:20, height:50)
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 5)
                                            .foregroundStyle(.gray)
                                        Text(shop.name)
                                            .foregroundStyle(.white)
                                    }
                                }
                            }
                        }
                    }
                }
                
                VStack {
                    Spacer()
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 10)
                            .frame(width:100, height: 50)
                            .shadow(color: .black, radius: 5)
                            .foregroundStyle(.white)
                        Button("Show Shops") {
                            clicked.toggle()
                        }
                    }
                    .offset(y:-50)
                    .onAppear(perform: {
                        let request = MKLocalSearch.Request()
                        request.naturalLanguageQuery = "Pizza Shop"
                        request.region = region
                        
                        let search = MKLocalSearch(request: request)
                        
                        search.start { (response, error) in
                            guard let response = response else { return }
                            for mapItem in response.mapItems {
                                shopsLocation.append(Shop(name: mapItem.name ?? "Unknown", coordinate: mapItem.placemark.coordinate, placemark: mapItem.placemark.title!, phoneNumber: mapItem.phoneNumber!))
                            }
                            
                        }
                    })
                }
            }
        }
    }
}

struct Shop: Identifiable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
    let placemark: String
    let phoneNumber: String
}

