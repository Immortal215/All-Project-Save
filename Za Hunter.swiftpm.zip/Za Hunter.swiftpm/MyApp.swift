import SwiftUI
import MapKit
import CoreLocation

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
