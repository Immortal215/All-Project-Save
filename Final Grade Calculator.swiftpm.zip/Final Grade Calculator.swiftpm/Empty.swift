import SwiftUI

struct Empty: View {
    var body: some View {
        Rectangle()
            .frame(width: 0, height: 0, alignment: .center)
    }
}

