import SwiftUI

struct ContentView: View {
    @State var grade = 0.0
    @State var dGrade = 93.0
    @State var examPercent = 0.0
    @State var calcNum = 0.0
    @State var topP = 0.0
    @State var topN = 0.0
    @State var output = ""
    var body: some View {
        ZStack {
            Rectangle()
                .foregroundColor(color())
                .opacity(/*@START_MENU_TOKEN@*/0.8/*@END_MENU_TOKEN@*/)
            VStack {
              Text("Final Grade Calculator")
                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .position(x: 220.0,y: 40.0)
            }
            VStack {
                Divider()
                TextField("Current Grade", value : $grade, format: .number)
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 30, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .textFieldStyle(.roundedBorder)
                    .fontWeight(.bold)
                    .padding()
                
                    .onSubmit {
                        if (grade != 0.0 && dGrade != 0.0 && examPercent != 0.0){
                            math()
                            
                        } 
                    }
                Text("Current Grade")
                    .fontWeight(.heavy)
                Divider()
                TextField("Desired Final Grade", value : $dGrade, format: .number)
                    .frame(width: 100, height: 30, alignment: .center)
                    .textFieldStyle(.roundedBorder)
                    .fontWeight(.bold)
                    .padding()
                    .onSubmit {
                        if (grade != 0.0 && dGrade != 0.0 && examPercent != 0.0){
                            math()                        
                        } 
                    }
                Text("Desired Final Grade")
                    .fontWeight(.heavy)
                Divider()
                TextField("Exam worth", value : $examPercent, format: .number)
                    .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 30, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .textFieldStyle(.roundedBorder)
                    .fontWeight(.bold)
                    .padding()
                    .onSubmit {
                        if (grade != 0.0 && dGrade != 0.0 && examPercent != 0.0){
                            math() 
                        } 
                    }
                Text("Exam Worth")
                    .fontWeight(.heavy)
                Divider()
                Picker("",selection: $dGrade) { 
                    Text("A").tag(90.00)
                    Text("B").tag(80.00)
                    Text("C").tag(70.00)
                    Text("D").tag(60.00)
                }
                .pickerStyle(.segmented)
                Divider()
                Picker("",selection: $dGrade) { 
                    Text("A").tag(90.00)
                    Text("B").tag(80.00)
                    Text("C").tag(70.00)
                    Text("D").tag(60.00)
                }
                .pickerStyle(.wheel)
               
                
                

                Text("Desired Final Grade")
                    .fontWeight(.heavy)
                
                Divider()
                if calcNum > 100 {
                    Text("You need to get \(calcNum ?? 0, specifier: "%.2f")% on the test. Extra credit is the only way! ")
                        .fontWeight(.heavy)
                        .foregroundColor(calcNum > 0.00 ? .black : .white) 
                } else {
                    Text("You need to get \(calcNum ?? 0, specifier: "%.2f")% on the test to get a \(dGrade ?? 0, specifier: "%.2f")%")
                        .fontWeight(.heavy)
                        .foregroundColor(calcNum > 0.00 ? .black : .white) 
                }
                
                
            }
        }
    }
    func math(){
        topP = (1.00 - (examPercent / 100.00))
        topN = (dGrade - (topP * grade))
        calcNum = (topN / (examPercent / 100.00))        
    }
    func color() -> Color {
        if calcNum > 0.00 {
            return calcNum > 100.00 ? .red : .green
        } else {
            return .white
        }

    }
}

