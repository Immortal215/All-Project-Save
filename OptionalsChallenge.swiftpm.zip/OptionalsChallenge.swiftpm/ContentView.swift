import SwiftUI

struct ContentView: View {
    let listItems = ["MVP","Stretch #1","Stretch #2","Stretch #3"]
    var body: some View {
        HeaderView()
        NavigationStack {
            List(listItems, id: \.self) { i in 
                NavigationLink(i) {
                    if i == "MVP" {
                        MVPView()
                    } else if i == "Stretch #1" {
                        Stretch1View()
                    } else if i == "Stretch #2" {
                        Stretch2View()
                    } else {
                        Stretch3View()
                    }
                }
                .font(.largeTitle)
                .padding()
            }
        }
        FooterView()
    }
}
