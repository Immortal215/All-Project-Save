import SwiftUI

struct Stretch1View: View {
    @State var number1: Int?
    @State var number2: Int?
    @State var answer: Int = 0
    
    var body: some View {
        
        //MARK: Stretch #1
        TextField("Enter Number 1", value: $number1, format: .number)
            .textFieldStyle(.roundedBorder)
        TextField("Enter Number 2", value: $number2, format: .number)
            .textFieldStyle(.roundedBorder)
        Button {
            answer = ((number1 ?? 1) * (number2 ?? 1))
        } label : {
            Text("Click To display product")
        }
        Text("Product: \(answer)")        
        
        
        
    }
}

