import SwiftUI

struct Stretch3View: View {
    @State var number1: Int?
    @State var number2: Int?
    @State var answer: Int = 0
    @State var presentAlert = false
    @FocusState private var focusedField: String?
    
    var body: some View {
        
        //MARK: Stretch #2
        TextField("Enter Number 1", value: $number1, format: .number)
            .textFieldStyle(.roundedBorder)
        TextField("Enter Number 2", value: $number2, format: .number)
            .textFieldStyle(.roundedBorder)
        Button {
            answer = ((number1 ?? 1) * (number2 ?? 1))
            guard let number = number1 else { return presentAlert = true }
            guard let number = number2 else { return presentAlert = true }

        } label : {
            Text("Click To display product")
        }
        .alert("You Entered Something wrong", isPresented: $presentAlert) {
            Text("You Monkey!")
        }
        Text("Product: \(answer)")              
    }
}

