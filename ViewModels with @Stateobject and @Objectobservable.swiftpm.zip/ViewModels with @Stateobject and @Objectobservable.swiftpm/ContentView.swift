import SwiftUI

struct PizzaModel: Identifiable {
    let id: String = UUID().uuidString
    let name: String
    let count: Int
}

class PizzaViewModel: ObservableObject {
    
    @Published var pizzaArray: [PizzaModel] = []
    
    func getPizzas() {
        let pizza1 = PizzaModel(name: "pineapple", count: 4)
        let pizza2 = PizzaModel(name: "olives", count: 3)
        
        pizzaArray.append(pizza1)
        pizzaArray.append(pizza2)
    }
    
    func deletePizza(index: IndexSet) {
        pizzaArray.remove(atOffsets: index)
    }
    
}

struct ContentView: View {
    
    @ObservedObject var pizzaViewModel: PizzaViewModel = PizzaViewModel()
    
    var body: some View {
        NavigationView{
            List{
                ForEach(pizzaViewModel.pizzaArray) { pizza in
                    HStack {
                        Text("\(pizza.count)")
                            .foregroundColor(.red)
                        Text("\(pizza.name)")
                            .font(.headline)
                            .bold()
                    }
                }
                .onDelete(perform: pizzaViewModel.deletePizza)
            }
            .listStyle(GroupedListStyle())
            .navigationTitle("Pizza List")
            .onAppear {
                pizzaViewModel.getPizzas()
            }
        }
    }
}
