import SwiftUI

struct Settinger: View {
    var body: some View {
        Text("HI")
    }
}
