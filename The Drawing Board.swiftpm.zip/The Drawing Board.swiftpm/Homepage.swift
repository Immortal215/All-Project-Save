import SwiftUI

struct Homepage: View {
    var body: some View {
        
        TabView(selection: .constant(1),
                content:  {
            Notebook().tabItem {Text("Assignment Notebook")}.tag(1)
           
            (Text("Work In Progress")).tabItem {Text("W.I.P.")}.tag(3)
            (Text("Work In Progress")).tabItem {Text("W.I.P.")}.tag(2)
            Settinger().tabItem {Text("Settings")}.tag(4)

        })
        
    }
}
