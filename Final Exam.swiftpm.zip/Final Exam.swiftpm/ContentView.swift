import SwiftUI

struct ContentView: View {
    @State var asset1 = 0
    @State var asset2 = 0
    @State var asset3 = 0
    @State var liability1 = 0
    @State var liability2 = 0
    @State var liability3 = 0
    @State var netWorth = 0
    @State var image = true
    
    var body: some View {
        VStack {
            Button("What is My Networth?") {
                netWorth = ((asset1 + asset2 + asset3) - (liability1 + liability2 + liability3))
            }
            .font(.largeTitle)
            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            .offset(x:0.0, y:-180.0)
        }
        Text("Your Networth is : $\(netWorth)")
            .font(.largeTitle)
            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
           .offset(x: 0.0, y: -140.0)
        Divider()
        VStack {
            Text("Asset Values")
                .font(.title)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .padding()
            HStack {
                VStack {
                    Text("Paycheck")
                        .fontWeight(.bold)
                    TextField("Asset Value in $", value: $asset1, format: .number)
                        .textFieldStyle(.roundedBorder)
                }
                
                VStack {
                    Text("Allowance")
                        .fontWeight(.bold)
                    TextField("Asset Value in $", value: $asset2, format: .number)
                        .textFieldStyle(.roundedBorder)
                }
                VStack {
                    Text("Gifts")
                        .fontWeight(.bold)
                    TextField("Asset Value in $", value: $asset3, format: .number)
                        .textFieldStyle(.roundedBorder)
                }
            }
            Divider()
        }
        .background(.green.opacity(0.8))
        .offset(x: 0.0, y: -140.0)
        VStack {
            Text("Liability Costs")
                .font(.title)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .padding()
            HStack {
                VStack {
                    Text("Netflix")
                        .fontWeight(.bold)
                    TextField("Asset Value in $", value: $liability1, format: .number)
                        .textFieldStyle(.roundedBorder)
                }
                VStack {
                    Text("Cell Phone")
                        .fontWeight(.bold)
                    TextField("Asset Value in $", value: $liability2, format: .number)
                        .textFieldStyle(.roundedBorder)
                }
                VStack {
                    Text("Entertainment")
                        .fontWeight(.bold)
                    TextField("Asset Value in $", value: $liability3, format: .number)
                        .textFieldStyle(.roundedBorder)
                }
            }
            Divider()
          
        }
        .background(.red.opacity(0.8))
        .offset(x: 0.0, y: -148.0)
        Button(action: {
            asset1 = 0
            asset2 = 0 
            asset3 = 0 
            liability1 = 0 
            liability2 = 0 
            liability3 = 0 
            netWorth = 0  
            image.toggle()
        }, label: {
            Text("Clear")
        })
        .foregroundColor(.blue)
        .font(.largeTitle)
        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
        .offset(x:0.0, y:-148.0)
        if image == true {
             Image(systemName: "clear")
                .offset(x:0.0, y:-148.0)
        } else {
            
        }
        
    }
    
    
}
