import SwiftUI

//MARK: Stretch #3 - Part III
struct DetailView:View {
    @State var name = ""
    @State var age = 0
    var body: some View { 
        VStack {
            Text("Name : \(name)\n\nAge : \(age)")
        }
        
    }
}

