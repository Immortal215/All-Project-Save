import SwiftUI

struct MVPView: View {
    //MARK: MVP - Part I
    @State var worldCurrencies = ["USD", "Euro", "Pounds", "Pesos", "Yen"]
    
    var body: some View {
        VStack {
            Text("World Currencies")
            
            //MARK: MVP - Part II
            List(worldCurrencies, id: \.self) { i in 
                Text(i)
            }

        }
    }
}

