import SwiftUI

struct Stretch2View: View {
    //MARK: Stretch #2 - Part II
    @State var people:[Person] = [
    Person(name: "Sharul", age: 15),
    Person(name: "Nishar", age: 17),
    Person(name: "Daniel", age: 16)
    ]
    
    
    
    var body: some View {
        //MARK: Stretch #2 - Part III
        List(people, id: \.self) { i in
            Text("Name : \(i.name)\n\nAge : \(i.age ?? 1)\n")
        }
        
        
        
    }
}

