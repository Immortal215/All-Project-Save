import SwiftUI

//MARK: Stretch #2 - Part I
struct Person:Hashable {
    var name:String
    var age:Int? 
}
