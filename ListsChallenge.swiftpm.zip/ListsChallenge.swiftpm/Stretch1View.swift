import SwiftUI

struct Stretch1View: View {
    //MARK: Stretch #1 - Part I
    @State var enteredAnimal = ""
    @State var animals:[String] = ["~ Enter Animals ~"]
    
    
    
    
    var body: some View {
        VStack {
            //MARK: Stretch #1 - Part II
            TextField("Enter Animal", text: $enteredAnimal)
                .onSubmit {
                    animals.append(enteredAnimal)
                    enteredAnimal = ""
                }
            
            List(animals, id: \.self) { i in 
                Text(i)
            }
            
            
            
        }
    }
}

