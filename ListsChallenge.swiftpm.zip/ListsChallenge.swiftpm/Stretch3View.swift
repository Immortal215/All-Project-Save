import SwiftUI


struct Stretch3View: View {
    //MARK: Stretch #3 - Part I
    @State var people:[Person] = [
        Person(name: "Sharul", age: 15),
        Person(name: "Nishar", age: 17),
        Person(name: "Daniel", age: 16)
    ]
    
    var body: some View {
        //MARK: Stretch #3 - Part II
        VStack {
            Text("Click each name for more info")
            NavigationView() {
                List(people, id:\.self) { i in
                    NavigationLink {
                        DetailView(name: "\(i.name)", age: i.age ?? 1)
                    } label : {
                        Text("\(i.name)")
                    }
                    
                }
            }
        }
        
        
    }
}

