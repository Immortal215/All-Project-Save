import SwiftUI

//MARK: Stretch #2 - Part I
@propertyWrapper struct BetweenOneAndTen {
    var wrappedValue: Int {
        didSet {
            
        }
    }
    init(wrappedValue: Int) {
        self.wrappedValue = wrappedValue
        
        if wrappedValue > 10 {
            self.wrappedValue = Int.random(in: 1..<10)
        } else if wrappedValue < 0 {
            self.wrappedValue = Int.random(in: 1..<10)
        } 
    }
}                                                    
class BoundedNumber {
    
    //MARK: Stretch #2 - Part II
    @BetweenOneAndTen var number: Int
    
    init(number: Int) {
        self.number = number
    }
}
