import SwiftUI


//MARK: Stretch #1 - Part I
class Contact: ObservableObject{
   @Published var name = ""
   @Published var address = ""
   @Published var phone = ""
    
}
