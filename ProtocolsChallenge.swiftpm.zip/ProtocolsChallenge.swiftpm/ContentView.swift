import SwiftUI

struct ContentView: View {
    //MARK: Stretch #2 - Part II
    
    
    
    
    var body: some View {
        HeaderView()
        Spacer()
        Text("MVP Works")
        //MARK: MVP - Part II
            
        
        
        
        
        //MARK: Stretch #1 - Part II
        
        
        
        
        
        //MARK: Stretch #2 - Part III
        
        
        
        
        
        //MARK: Stretch #3 - Part II
       
        
        
        
        
        Spacer()
        FooterView()
    }
}
