import SwiftUI

struct ContentView: View {
    @State var num1 = 0.0
    @State var num2 = 0.0
    @State var symbol = ""
    @State var num = 0.0
    var body: some View {
        VStack {
            HStack{
                TextField("Number 1",value :$num1, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 50, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                TextField("+",text: $symbol)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 25, height: 25, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                
                TextField("Number 2", value: $num2, format:.number)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 50, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                Text("=  \(Int(num))") 
            }
            .frame(width: 200, height: 75, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            
            //            else if (num != 64 && num % 2 == 0){
            //                Text("2")
            //            } else if (num != 64 && num % 2 != 0){
            //                Text("3")
            //            }
            //            
            
            Text("Number 1")
            Slider(value: $num1, in: 1...100, step: 1) {
                
            } minimumValueLabel: {
                Text("0")
            } maximumValueLabel: {
                Text("100")
            } 
            .offset(x: 0, y: -50)
            .frame(width: 300, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            Text("Number 2")
                .offset(x: 0.0, y: -75)
            
            Slider(value: $num2, in: 1...100, step: 1)
            {
                
            }minimumValueLabel: {
                Text("0")
            } maximumValueLabel: {
                Text("100")
            } 
            .frame(width: 300, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .offset(x: 0.0, y: -125)
            
            Button("Calculate"){
                if (symbol == "*" || symbol == "x" || symbol == "X") {
                    num = num1 * num2
                } else if (symbol == "-"){
                    num = num1-num2
                    
                } else if (symbol == "+"){
                    num = num1+num2
                } else if (symbol == "/") {
                    num = num1/num2
                    
                } else if (symbol == "%") {
                    
                    if (num2 != 0){
                        num = Double(Int(num1) % Int(num2))
                    } 
                } 
            }
            .foregroundColor(.white)
            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .background(in: RoundedRectangle(cornerRadius:10))
            .offset(x: 0.0, y: -150.0)
            
            if (num == 64){
                Image("Peach")
                    .offset(x: 0, y: -125)
            } else if (num != 64 && Int(num) % 2 == 0 && num != 0){
                Image("Funny")
                    .offset(x: 0, y: -125)
            } else if (num != 64 && Int(num) % 2 != 0 && num != 0){
                Image("Funnier")
                    .offset(x: 0, y: -125)
            }
            
            Button("Clear"){
                num1 = 0.0
                num2 = 0.0
                num = 0.0
                symbol = ""
                
            }
            
                
            
            .foregroundColor(.white)
            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            .background(in: RoundedRectangle(cornerRadius:10))
            .offset(x: 0, y: -125)
        }
        
        
    }
}
