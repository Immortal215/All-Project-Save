import SwiftUI

struct ContentView: View {
    
//    @State var currentUserName: String?
    @AppStorage("name") var currentUserName: String?
    var body: some View {
        VStack(spacing: 20) {
            
            Text(currentUserName ?? "Add Name Here")
            
            if let name = currentUserName {
                Text(name)
            }
            
            Button("Save") {
//                let name = "Sharul"
                currentUserName = "Sharul"
//                UserDefaults.standard.set(name, forKey: "name")
        
            }
            
        }
//        .onAppear {
//            currentUserName = UserDefaults.standard.string(forKey: "name")
//        }
    }
}
