import SwiftUI

//// MARK: - Stretch #3 - Part I
struct Contact: Codable {
    var name:String
    var age:Int
    var phoneNumber: Int
}


