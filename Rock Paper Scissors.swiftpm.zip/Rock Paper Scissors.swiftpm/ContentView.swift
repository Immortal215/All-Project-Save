import SwiftUI

struct ContentView: View {
    @State var rockChosen = false 
    @State var paperChosen = false
    @State var scissorsChosen = false 
    @State var moveChosen = false
    @State var moveChosen2 = false
    @State var rockMover = false
    @State var paperMover = false
    @State var scissorMover = false
    @State var chosenMover = false
    @State var reset = false
    @State var enemyPlayer = "Placeholder"
    @State var chosenMove = "Placeholder"
    @State var win = "Placeholder"
    @State var wins = 0
    @State var losses = 0 
    @State var tie = 0 

    
    
    var body: some View {
        VStack(spacing:30) {
            HStack {
                
                Button {
                    rockChosen = false 
                    paperChosen = false
                    scissorsChosen = false 
                    moveChosen = false
                    moveChosen2 = false
                    rockMover = false
                    paperMover = false
                    scissorMover = false
                    chosenMover = false
                    reset = false
                    enemyPlayer = ""
                    chosenMove = ""
                    win = "" 
                    wins = 0
                    losses = 0 
                    tie = 0 
                } label: {
                    HStack {
                        VStack {
                            Text("Wins : \(wins)")
                            Text("Losses : \(losses)")
                            Text("Ties : \(tie)")
                        }
                        .foregroundColor(reset ? .yellow : .clear)
                        Text(reset ?  "RESTART" : "ROCK, PAPER, SCISSORS!")
                            .foregroundColor(reset ? .yellow : .green)
                            .font(Font.custom("", fixedSize: 45))
                            .fontWeight(.bold) 
                      
                    }
                    

                }
                .offset(x: -20.0, y: -170.0)
                
                Link(destination: URL(string:"https://thegeniusofplay.org/genius/play-ideas-tips/play-ideas/rock-paper-scissors.aspx")!, label: {
                    Image(systemName: "info.circle")
                        .foregroundColor(.blue)
                })
                .offset(x: 190.0, y: -200.0)
                
            }
            .offset(y: 20)
            
            VStack (spacing:30) {
                Text(moveChosen2 ? "You have chosen: " : "Choose Your Move")
                    .font(Font.custom("", fixedSize: 45))
                    .fontWeight(.bold) 
                
                
                
                Divider()
                HStack {
                    Button {
                        reset = true
                        chosenMove = "Rock"
                        if chosenMover == false {
                            rockChosen.toggle()
                            paperChosen = false 
                            scissorsChosen = false
                            if paperMover == false {
                                paperMover = true
                                scissorMover = true
                                moveChosen = true 
                            } else {
                                paperMover = false
                                scissorMover = false
                                moveChosen2 = false
                                moveChosen = false
                            }
                        } else {
                            
                        }
                    } label: {
                        VStack {
                            Image("Rock")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .border(rockChosen ? .blue : .black, width: rockChosen ? 3 : 5)
                            
                            Text("Rock")
                                .font(Font.custom("", size: 25))
                                .foregroundColor(.white)
                                .shadow(color: .white, radius: 10, x: 0.0, y: 0.0)
                        }
                    }
                    .background(rockChosen ? .blue : .black, in: RoundedRectangle(cornerRadius:10))
                    .frame(width: rockMover ? 0 : 100, height: rockMover ? 0 : 100)
                    .offset(x: rockMover ? 70.0 : 1.0)
                    .opacity(rockMover ? 0.0 : 1.0)
                    .animation(.easeInOut(duration: 0.365))
                    
                    Button {
                        reset = true
                        chosenMove = "Paper"
                        if chosenMover == false {
                            paperChosen.toggle()
                            rockChosen = false
                            scissorsChosen = false
                            if rockMover == false {
                                rockMover = true 
                                scissorMover = true
                                moveChosen = true
                            } else {
                                rockMover = false
                                scissorMover = false
                                moveChosen2 = false
                                moveChosen = false
                            }
                        } else {
                        }
                    } label: {
                        VStack {
                            Image("Paper")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .border(paperChosen ? .blue : .black, width: paperChosen ? 3 : 5)
                            
                            Text("Paper")
                                .font(Font.custom("", size: 25))
                                .foregroundColor(.white)
                                .shadow(color: .white, radius: 10, x: 0.0, y: 0.0)
                        }
                    }
                    .background(paperChosen ? .blue : .black, in: RoundedRectangle(cornerRadius:10))
                    .frame(width: paperMover ? 0 : 100, height: paperMover ? 0 : 100)
                    .opacity(paperMover ? 0.0 : 1.0)
                    .animation(.easeInOut(duration: 0.314159))
                    
                    Button {
                        reset = true
                        chosenMove = "Scissors"
                        if chosenMover == false {
                            scissorsChosen.toggle()
                            rockChosen = false 
                            paperChosen = false
                            if rockMover == false {
                                rockMover = true
                                paperMover = true
                                moveChosen = true
                            } else {
                                rockMover = false
                                paperMover = false
                                moveChosen2 = false
                                moveChosen = false
                            }
                        } else {
                            
                        }
                    } label: {
                        VStack {
                            Image("Scissors")
                                .resizable()
                                .frame(width: 100, height: 100)
                                .border(scissorsChosen ? .blue : .black, width: scissorsChosen ? 3 : 5)
                            
                            Text("Scissors")
                                .font(Font.custom("", size: 25))
                                .foregroundColor(.white)
                                .shadow(color: .white, radius: 10, x: 0.0, y: 0.0)
                        }
                    }
                    .background(scissorsChosen ? .blue : .black, in: RoundedRectangle(cornerRadius:10))
                    .frame(width: scissorMover ? 0 : 100, height: scissorMover ? 0 : 100)
                    .offset(x: scissorMover ? -50.0 : 0.0)
                    .opacity(scissorMover ? 0.0 : 1.0)
                    .animation(.easeInOut(duration: 0.365))
                    
                    
                }
                Divider()
                Button {
                    moveChosen = false
                    moveChosen2 = true
                    chosenMover = true
                    enemyPlayer = enemyPlay()
                    win = winloss()
                } label: {
                    Text("Submit Move")
                        .font(Font.custom("", fixedSize: 25))
                        .foregroundColor(moveChosen ? .cyan : .clear)
                        .shadow(color: .white, radius: 10, x: 0.0, y: 0.0)
                        .frame(width: moveChosen2 ? 400 : 200, height:50, alignment: .center)
                        .background(moveChosen ? .black : .clear, in: RoundedRectangle(cornerRadius:10))
                    
                }
            }
            .offset(x: 0.0 ,y: chosenMover ? -100.0 : 0.0)
            
            VStack {
                Text("Generating Move...")
                    .font(Font.custom("", fixedSize: 45))
                    .fontWeight(.bold) 
                    .foregroundColor(chosenMover ? .blue : .clear)
                
                // add animation here 
                VStack {
                    Image(enemyPlayer)
                        .resizable()
                        .frame(width: 100, height: 100)
                        .border(.black, width: 5)
                    
                    Text(enemyPlayer)
                        .font(Font.custom("", size: 25))
                        .foregroundColor(.white)
                        .shadow(color: .white, radius: 10, x: 0.0, y: 0.0)
                }
                    .foregroundColor(chosenMover ? .blue : .clear)
                    .background(.black, in: RoundedRectangle(cornerRadius:10))
                    .frame(width: chosenMover ? 100 : 0, height: chosenMover ? 100 : 0)
                    .opacity(chosenMover ? 1.0 : 0.0)
                    .animation(.easeIn(duration: 1))
                    .offset(y: 20.0)
                
                Text(win)
                    .font(Font.custom("", fixedSize: 45))
                    .fontWeight(.bold) 
                    .foregroundColor(chosenMover ? .orange : .clear)
                    .offset(y: 40.0)
                    .animation(.easeOut(duration: 1))
                Button {
                    
                    rockChosen = false 
                    paperChosen = false
                    scissorsChosen = false 
                    moveChosen = false
                    moveChosen2 = false
                    rockMover = false
                    paperMover = false
                    scissorMover = false
                    chosenMover = false
                    enemyPlayer = ""
                    chosenMove = ""
                    win = "" 
                    
                } label : {
                    Text("Play Again")
                        .font(Font.custom("", fixedSize: 45))
                        .fontWeight(.bold) 
                        .foregroundColor(chosenMover ? .orange : .clear)
                        .animation(.easeOut(duration: 1))
                        .frame(height: 100)
                        .background(chosenMover ? .yellow : .clear, in: RoundedRectangle(cornerRadius : 15))
                }
                .offset(y: 60.0)
            }
            .offset(y: -170.0)

        }
        .offset(y: chosenMover ? 115 : 30.0)
        
      
    }
    
    func enemyPlay() -> String{
        var play = Int.random(in: 0...2) 
        if play == 0 {
            return  "Paper"
        } else if play == 1 {
            return "Rock"
        } else {
             return "Scissors"
        }
        
    }
    
    func winloss() -> String {
        if enemyPlayer == "Rock" {
            if chosenMove == "Rock" {
                tie += 1
                return "Tie!"
            } else if chosenMove == "Paper" { 
                wins += 1
                return "You Win!"
            } else {
                losses += 1
                return "You lose!"
            }
        } else if enemyPlayer == "Paper" {
            if chosenMove == "Paper" {
                tie += 1
                return "Tie!"
            } else if chosenMove == "Scissors" { 
                wins += 1
                return "You Win!"
            } else {
                losses += 1
                return "You lose!"
            }
        } else {
            if chosenMove == "Scissors" {
                tie += 1
                return "Tie!"
            } else if chosenMove == "Rock" { 
                wins += 1
                return "You Win!"
            } else {
                losses += 1
                return "You lose!"
            }
        }
        
   }
        
 
}

