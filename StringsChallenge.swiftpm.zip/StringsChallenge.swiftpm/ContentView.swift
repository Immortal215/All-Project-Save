import SwiftUI

struct ContentView: View {
    @State var word = ""
    @State var firstLetter = ""
    @State var lastLetter = ""
    @State var numberOfLetters = ""
    @State var isWordEmpty = ""
    @State var uppercased = ""
    
    @State var find = ""
    @State var replace = ""
    @State var stretch1Answer = ""
    
    @State var definiteArticle = ""
    @State var noun = ""
    @State var verb = ""
    @State var adverb = ""
    
    @State var pigLatinWord = ""
    
    var body: some View {
        VStack {
            Group {
                Divider()
                Text("Strings Challenge")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .font(.title)
                Divider()
            }
            
            TextField("Please enter a String", text: $word)
                .textFieldStyle(.roundedBorder)
                .padding()
                .onChange(of: word, perform: { value in
                    //MARK: MVP 
                    
                    if word != "" {
                        isWordEmpty = String(word.isEmpty)
                        numberOfLetters = "\(word.count)"
                        firstLetter = String(word.capitalized.first!)
                        lastLetter = String(word.uppercased().last!)
                        uppercased = word.uppercased()
                    } else {
                        isWordEmpty = String(word.isEmpty)
                        numberOfLetters = "None"
                        firstLetter = "None"
                        lastLetter = "None"
                        uppercased = "None"
                    }
                    
                    
                    
                    
                })
            Group {
                
                
                Text("MVP")
                    .frame(maxWidth: .infinity, maxHeight: 30)
                    .font(.title)
                    .underline()
                
                HStack {
                    
                    VStack(alignment: .leading) {
                        Text("Number of Letters: ")
                        Text("Is Word Empty: ")
                        Text("First Letter: ")
                        Text("Last Letter: ")
                        Text("All Uppercased: ")
                    }
                    
                    VStack(alignment: .leading)  {
                        Text(numberOfLetters)
                        Text(isWordEmpty)
                        Text(firstLetter)
                        Text(lastLetter)
                        Text(uppercased)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding()
            
            Group {
                Text("Stretch #1")
                    .frame(maxWidth: .infinity)
                    .font(.title)
                    .underline()
                Button("Test Stretch #1") {
                    //MARK: Stretch #1
                    stretch1Answer = word.replacing(find, with: replace)
                    
                    
                    
                }
                HStack {
                    Text("Replace: ")
                    TextField("letter", text: $find)
                        .autocorrectionDisabled(true)
                    Text(" With: ")
                    TextField("letter", text: $replace)
                        .autocorrectionDisabled(true)
                }
                .textFieldStyle(.roundedBorder)
                .padding()
                
                Text(stretch1Answer)
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .center)
            }
            
            
            Group {
                Text("Stretch #2")
                    .frame(maxWidth: .infinity)
                    .font(.title)
                    .underline()
                Button("Test Stretch #2") {
                    //MARK: Stretch #2
                    let array = word.split(separator: " ")
                    definiteArticle = String(array[0])
                    noun = String(array[1])
                    verb = String(array[2])
                    adverb = String(array[3])
                }
                
                HStack {
                    
                    VStack(alignment: .leading) {
                        Text("Definite Article: ")
                        Text("Noun: ")
                        Text("Verb: ")
                        Text("Adverb: ")
                    }
                    
                    VStack(alignment: .leading)  {
                        Text(definiteArticle)
                        Text(noun)
                        Text(verb)
                        Text(adverb)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }
            
            
            Group {
                Text("Stretch #3")
                    .frame(maxWidth: .infinity)
                    .font(.title)
                    .underline()
                Button("Test Stretch #3") {
                    //MARK: Stretch #3
                    var array = word.split(separator: " ")
                    let pigLatinArray = ["a", "e", "i", "o", "u"]
                    let firstWord = word.first!
                    
                    if pigLatinArray.contains(String(firstWord)) {
                        pigLatinWord = word.dropFirst() + "yay"
                    } else {
                        var drop = word.dropFirst()
                        pigLatinWord = drop + "ay"
                    }
                    
                }
                
                Text(pigLatinWord)
                    .font(.title)
            }
            
            Spacer()
            Group {
                Image("MobileMakersEduNB")
                    .resizable()
                    .frame(maxWidth: .infinity)
                    .scaledToFit()
            }.padding()
        }
    }
}
