import SwiftUI
//MARK: MVP - Part I
import MapKit

struct ContentView: View {
    //MARK: MVP - Part II
    
    @State var region = MKCoordinateRegion(center : CLLocationCoordinate2D(latitude: 42.07925960001393, longitude: -87.94966775896395), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01) )    
    
    //MARK: Stretch #1 - Part II
    @State var locationArray = [Location(coordinates: CLLocationCoordinate2D(latitude:  42.08368412213557, longitude:  -87.94901537584744))]
    var body: some View { 
        
        HeaderView()
        
        NavigationStack {
            //MARK: MVP - Part III and Stretch #1 - Part III and Stretch #2
            Map(coordinateRegion: $region, interactionModes: []) 
            Map(interactionModes:[]) {
                Marker("Body Of Water", coordinate: locationArray[0].coordinates)
                    .tint(.blue)
            }
            .mapStyle(.standard)
            
            
            
            
            Spacer()
            NavigationLink { 
                //Stretch #3 - Part I
                Stretch3View(region: region)
                
                
                
            } label: { 
                Text("Stretch #3")
                    .frame(width: 300, height: 50, alignment: .center)
                    .background(.blue)
                    .foregroundColor(.white)
                    .clipShape(Capsule())
            }
        }
        FooterView()
        
    }
}
