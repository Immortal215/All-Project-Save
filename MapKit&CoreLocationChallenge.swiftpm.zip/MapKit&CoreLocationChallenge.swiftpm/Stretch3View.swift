import SwiftUI
import MapKit

struct Stretch3View: View {
    let region:MKCoordinateRegion
    @State var shops:[String] = []
    
    var body: some View {
        List(shops, id: \.self) { shop in 
            Text(shop)
        }
        .onAppear(perform: {
            //Stretch #3 - Part II
            let request = MKLocalSearch.Request()
    
            request.naturalLanguageQuery = "Coffee Shop"
            
            request.region = region
      
            let search = MKLocalSearch(request: request)
      
            search.start { (response, error) in
            
                guard let response = response else { return }
                for mapItem in response.mapItems {
                    shops.append(mapItem.name!)
                }
            }
            
            
            
        })
    }
}

