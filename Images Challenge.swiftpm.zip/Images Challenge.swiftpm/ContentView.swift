import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack{
            ZStack {
                Image("Picture")
                    .clipShape(Circle(), style: FillStyle())
                
                    .position(x: 203.0, y: 470.0)
                    .opacity(0.5)
                
                VStack{
                    HStack{
                        
                        Image(systemName: "arrow.left")
                            .resizable()
                            .aspectRatio(1.0, contentMode: .fit)
                            .rotationEffect(.degrees(45), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .position(x: 0.0, y: 450.0)
                            .frame(width: 20, height:20)
                            .overlay(Text("NW").font(Font.custom("yes",fixedSize:10))                 .position(x: -18.0, y: 435.0))
                        Image(systemName: "arrow.up")
                            .resizable()
                            .aspectRatio(1.0, contentMode: .fit)
                            .position(x: 0.0, y: 450.0)
                            .frame(width: 20, height:20)
                            .overlay(Text("N").font(Font.custom("yes",fixedSize:25))                 .position(x: 0.0, y: 425.0))
                        
                        Image(systemName: "arrow.up")
                            .resizable()
                            .aspectRatio(1.0, contentMode: .fit)
                            .rotationEffect(.degrees(45), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .position(x:0.0, y: 450.0)
                            .frame(width: 20, height:20)
                            .overlay(Text("NE").font(Font.custom("yes",fixedSize:10))                 .position(x: 18.0, y: 435.0))
                    }
                    HStack{
                        Image(systemName: "arrow.left")
                            .resizable()
                            .aspectRatio(1.0, contentMode: .fit)
                            .frame(width: 20, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .position(x: 178.0, y: 450.0)
                            .overlay(Text("W").font(Font.custom("yes",fixedSize:25))                 .position(x: 153.0, y: 453.0))
                        
                        Image(systemName:"globe")
                        
                            .frame(width: 20, height: 20, alignment: .center)
                            .position(x:60.0, y:450.0)
                        
                        Image(systemName:"arrow.right")
                            .resizable()
                            .aspectRatio(1.0, contentMode: .fit)
                            .frame(width: 20, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .position(x: -58.0, y: 450.0)       .overlay(Text("E").font(Font.custom("yes",fixedSize:25))                 .position(x:-38, y: 452.0))
                        
                    }
                    
                    
                    HStack{
                        Image(systemName: "arrow.down")
                            .resizable()
                            .aspectRatio(1.0, contentMode: .fit)
                            .frame(width: 20, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .rotationEffect(.degrees(45), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) .position(x:178, y: 0.0)       .overlay(Text("SW").font(Font.custom("yes",fixedSize:10))                 .position(x:158, y: 15.0))
                        
                        Image(systemName: "arrow.down")
                            .resizable()
                            .aspectRatio(1.0, contentMode: .fit)
                            .frame(width: 20, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .position(x: 60.0, y: 0.0)       .overlay(Text("S").font(Font.custom("yes",fixedSize:25))                 .position(x:60.0, y: 25.0))
                        
                        
                        Image(systemName:"arrow.right")
                            .resizable()
                            .rotationEffect(.degrees(45), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)                        
                            .aspectRatio(1.0, contentMode: .fit)
                            .frame(width: 20, height: 20, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .position(x: -58.0, y: 0.0)       .overlay(Text("SE").font(Font.custom("yes",fixedSize:10))                 .position(x:-38.0, y: 15.0))
                        
                        
                        
                        
                    }
                }
            }

            
            
        }
        
    }
}
