import SwiftUI
struct ContentView: View {
    var body: some View {
        VStack {
            Text("Red")
                .foregroundColor(.red)
            Text("Blue")
                .background(.blue)
            Text("Big")
                .font(.system(size:100))
            Text("Small")
                .font(.custom("small", fixedSize:8))
            Text("Left")
                .frame(width:400,alignment:.leading)
            Text("Right")
                .frame(width:400,alignment:.trailing)
        }
        VStack(alignment:.center,spacing:0){
            Text("Upside Down")
                .rotationEffect(.degrees(180), anchor:.center)
        }
        VStack(alignment:.center,spacing:60){
            Text("Cool Class")
                .foregroundColor(.white)
                .background(.black)
                .font(Font.custom("Zapfino", fixedSize: 25))
            Text("With Blue Border \n          Size 10 \n Frame 200 by 200")
                .frame(width:200, height:200,alignment:.center)
                .background(.yellow)
                .border(.blue,width:10)
            Text("😀")
                .font(.custom("yes",fixedSize:100))
                .frame(width:200,height:100)
                .background(Gradient(colors: [.white,.red]))
            Text("Hello World")
                .background(Image("Monkey"))
                .foregroundColor(.white)
                .font(.custom("small",fixedSize:30))
        }
    }
}
