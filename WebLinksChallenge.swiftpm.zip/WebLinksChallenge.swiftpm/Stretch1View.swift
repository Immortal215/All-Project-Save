import SwiftUI

struct Stretch1View: View {
    @Binding var enteredURL: URL
    
    //MARK: Stretch #1 - Part I
    @Environment(\.openURL) var openURL
    
    var body: some View {
        
        VStack {
            Text("Stretch #1")
                .font(.largeTitle)
                .underline()
                .padding()
            
            Spacer()
            
            //MARK: Stretch #1 - Part II
            Button(action: {
                openURL(URL(string: "\(enteredURL)")!)
            }, label: {
                Text("OpenURL Using Button")
            })

            Spacer()
            
            //MARK: Stretch #1 - Part III
            Button(action: {
                openURL(URL(string: "\(enteredURL)")!)
            }, label: {
                Image(systemName: "link")
            })
            

            
            
            
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        
    }
}

