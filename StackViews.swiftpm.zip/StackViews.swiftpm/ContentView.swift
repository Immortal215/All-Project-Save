import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            
            VStack() {
                VStack(alignment:.trailing){
                    Text("0")
                        .font(Font.custom("SF Mono", fixedSize: 100))   
                        .frame(width: 380, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .trailing)
                    
                }
                HStack{
                    Circle()
                        .opacity(0.8)
                        .overlay(Text("AC")
                            .colorInvert())
                    
                    Circle()
                        .opacity(0.8)
                        .overlay(Text("+/-")
                            .colorInvert())
                    Circle()
                        .opacity(0.8)
                        .overlay(Text("%")
                            .colorInvert())
                    Circle()
                        .foregroundColor(.orange)
                        .overlay(Text("÷")
                            .opacity(1.0))
                }
                HStack{
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("7")
                            .opacity(1.0))
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("8")
                            .opacity(1.0))
                    
                    
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("9")
                            .opacity(1.0))
                    
                    
                    Circle()
                        .foregroundColor(.orange)
                        .overlay(Text("x")
                            .opacity(1.0))
                }
                HStack{
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("4")
                            .opacity(1.0))
                    
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("5")
                            .opacity(1.0))
                    
                    
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("6")
                            .opacity(1.0))
                    
                    
                    Circle()
                        .foregroundColor(.orange)
                        .overlay(Text("-")
                            .opacity(1.0))
                }
                HStack{
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("1")
                            .opacity(1.0))
                    
                    
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("2")
                            .opacity(1.0))
                    
                    
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("3").opacity(1.0))
                    
                    
                    Circle()
                        .foregroundColor(.orange)
                        .overlay(Text("+")
                            .opacity(1.0))
                }
                HStack{
                    Capsule()
                        .frame(width: 210, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                        .foregroundColor(.gray)
                        .opacity(0.65)
                        .overlay(Text("0")
                            .frame(width: 125, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: .leading)
                            .opacity(1.0))
                    
                    
                    
                    Circle()
                        .foregroundColor(.gray)
                    
                        .opacity(0.65)
                        .overlay(Text(".")
                                 
                            .opacity(1.0))
                    
                    
                    Circle()
                        .foregroundColor(.orange)
                        .overlay(Text("=")
                            .opacity(1.0))
                }
            }  
            .font(Font.custom("SF Mono",fixedSize:40))
            
            
        }
        
        
    }
}
