import SwiftUI

struct ContentView: View {
    @State var myText: String = "Start Text"
    @State var count: Int = 0 
    var body: some View {
        VStack {
            Text("Rectangles shown = \(count)")
            NavigationView{
                ScrollView{
                    Text(myText)
                    LazyVStack{
                        ForEach(0..<50){ _ in
                            RoundedRectangle(cornerRadius: 25.0)
                                .frame(height:200)
                                .padding()
                            //don't need perform: {}
                                .onAppear {
                                    count += 1 
                                }
                                .onDisappear {
                                    count -= 1
                                }
                        }
                    }
                }
                .onAppear(perform: { 
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5, execute: {
                        myText = "This is the new text!"
                    })
                })
                .onDisappear(perform: {
                    myText = "Ending Text"
                })
            }
        }
    }
}
