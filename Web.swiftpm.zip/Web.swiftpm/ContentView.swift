import SwiftUI

struct ContentView: View {
    @State var amazonUrl = URL(string: "https://www.amazon.com")!
    
    var body: some View {
        Link("Enter Amazon", destination: amazonUrl) 
        Divider()
        Link(destination: URL(string: "https://www.apple.com")!, label: {
            Image(systemName: "apple.logo")
            Text("Apple")
        })
    }
}
