//
//  Student.swift
//  ClassesChallenge
//
//  Created by Robert Englund
//  Copyright © 2022 MobileMakersEdu. All rights reserved.
//


// MARK: MVP - Part I
class Student {
    var firstName = "Sharul"
    var lastName = "Sharul" 
    
    
    
    
    
    
    
    // MARK: Stretch #1 - Part I
    var idNumber:String
    var favoriteColor:String
    
    init() {
        idNumber = "227371"
        favoriteColor = "Blue"
    } 
    
    
    
    // MARK: Stretch #2 - Part I
    init(firstName:String, lastName:String, idNumber:String, favoriteColor:String){
        self.firstName = firstName
        self.lastName = lastName
        self.idNumber = idNumber
        self.favoriteColor = favoriteColor
    }
    
    
    
    // MARK: - Stretch #3 - Part I
    func sayHello() -> String {
        return "Hello \(firstName) \(lastName), your ID number is \(idNumber)" 
    }
}
