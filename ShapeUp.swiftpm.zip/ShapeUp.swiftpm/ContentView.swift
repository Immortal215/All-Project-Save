import SwiftUI
struct ContentView: View {
    var body: some View {
        VStack(){
            Circle()
                .size(width: 100, height: 100)
                .background(.blue)  
            Rectangle()
                .trim(from:0.0, to:0.75)
                .fill(.green)
            Ellipse()
                .stroke(.orange, lineWidth: 5)
                .background(.brown)
            Capsule()
                .frame(width:300, height:100, alignment:.center)
                .foregroundColor(.cyan)
            RoundedRectangle(cornerRadius:10)
                .frame(width: 200, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .foregroundColor(.red)
        }
        VStack{
            Rectangle()
                .foregroundColor(.blue)
                .background(.black)
                .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, height: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/, width: 20)
            RoundedRectangle(cornerRadius:10)
                .frame(width: 300, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .foregroundColor(.blue)
                .overlay(Text("Click Me"))
                .foregroundColor(.white)
                .font(Font.custom("American Typewriter", fixedSize:35)) 
            Rectangle()
                .trim(from:0.0, to:0.5)
                .rotation(.degrees(-45), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .frame(width: 100, height: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .foregroundColor(.yellow)
                .padding(20)
                .offset(x: 0, y: 0)
        }
    }
}
