import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment:.leading , spacing:30) {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
      //      Spacer()
            Text("Green Bay Sux")
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
        .background(LinearGradient(colors: [.yellow,.white,.blue,.white,.yellow], startPoint: .bottomTrailing, endPoint: .topLeading))
       // .ignoresSafeArea()
    }
}





































