import SwiftUI

//MARK: Stretch #3 
struct ChoiceView: View {
    @State var change = false
    @State var counter = 0
    @State var width:CGFloat = 75
    @State var height:CGFloat = 125
    
    var body: some View {
        Button {
            counter += 1
            change.toggle()
            if counter == 1 {
                width = 200
                height = 200
                counter = 1 
            } 
            if counter == 2 {
                width = 100
                height = 100
            }
            if counter == 3 {
                width = 50
                height = 200
            } 
            if counter == 4 {
                width = 200
                height = 50
                print(counter)
                counter = 0
            }
            
        } label : {
            RoundedRectangle(cornerRadius: change ? 100 : 10)
                .foregroundColor(change ? .green : .cyan)
                .frame(width: width, height: height)
            
        }
    }
}


